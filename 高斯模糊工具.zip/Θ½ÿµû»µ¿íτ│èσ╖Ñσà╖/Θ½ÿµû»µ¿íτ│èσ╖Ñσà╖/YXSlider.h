//
//  YXSlider.h
//  高斯模糊工具
//
//  Created by admin on 16/12/22.
//  Copyright © 2016年 Poco.yyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YXSlider : UISlider

@end
