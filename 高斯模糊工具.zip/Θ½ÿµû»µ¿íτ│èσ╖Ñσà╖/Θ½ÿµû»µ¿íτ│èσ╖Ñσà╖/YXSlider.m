//
//  YXSlider.m
//  高斯模糊工具
//
//  Created by admin on 16/12/22.
//  Copyright © 2016年 Poco.yyx. All rights reserved.
//

#import "YXSlider.h"

@implementation YXSlider

- (CGRect)thumbRectForBounds:(CGRect)bounds trackRect:(CGRect)rect value:(float)value

{
    //y轴方向改变手势范围
    
    rect.origin.y= rect.origin.y-10;
    
    rect.size.height= rect.size.height+20;
    
    
    return CGRectInset([super thumbRectForBounds:bounds trackRect:rect value:value],10,10);
    
}


@end
