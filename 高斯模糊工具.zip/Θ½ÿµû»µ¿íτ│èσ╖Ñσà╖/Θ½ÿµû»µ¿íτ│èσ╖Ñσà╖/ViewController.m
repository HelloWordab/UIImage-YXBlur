//
//  ViewController.m
//  高斯模糊工具
//
//  Created by admin on 16/12/20.
//  Copyright © 2016年 Poco.yyx. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+YXBlur.h"
#import "UIImage+ImageEffects.h"
#import "YXSlider.h"
#define YXRATIO CGRectGetHeight(self.view.bounds)/667

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UIGestureRecognizerDelegate>

@property (nonatomic,copy) UIImageView *imageView; //图片
@property (nonatomic,copy) UISlider *sliderView; //模糊度进度条;
@property (nonatomic,copy) UISlider *sliderViewRadius; //半径进度条;
@property (nonatomic,copy) UISlider *sliderViewSaturationDeltaFactor; //饱和度
@property (nonatomic,copy) UIImage *image;//模糊图片
@property (nonatomic,copy) UIImage *maskImage; //遮罩
@property (nonatomic,strong) UIButton *button; //选图
@property (nonatomic,strong) UIButton *buttonMask; //选图
@property (nonatomic) BOOL isMaskImage;//标示
@property (nonatomic,copy) UIImagePickerController *pickerController;//系统相册
@property (nonatomic) BOOL isExchange;//更换模式的标示
@property (nonatomic,copy) UILabel *labelWelcome;//欢迎
@property (nonatomic,copy) UIView *ballView;//弹框视图
@property (nonatomic,copy) UITextField *tfBlur;//显示饱和度
@property (nonatomic,copy) UITextField *tfBlurRadius;//显示半径
@property (nonatomic,copy) UITextField *tfSaturationDeltaFactor;//显示饱和度
@property (nonatomic, nonnull,copy) UIButton *buttonCancelMask;//取消遮罩层
@property (nonatomic,strong) UIButton *buttonChangeColor;//改变颜色
@property (nonatomic,strong) UIColor *tintColor;//模糊颜色
@property (nonatomic,copy) UIView *colorView;//颜色视图
@property (nonatomic,copy) UIView *exchangeColorView;//修改颜色的视图
@property (nonatomic,copy) UISlider *sliderR;//R
@property (nonatomic,copy) UISlider *sliderG;//G
@property (nonatomic,copy) UISlider *sliderB;//B;
@property (nonatomic,copy) UISlider *sliderAlpha;//透明度
@property (nonatomic,copy) UILabel *labelR;
@property (nonatomic,copy) UILabel *labelG;
@property (nonatomic,copy) UILabel *labelB;
@property (nonatomic,copy) UILabel *labelAlpha;
@property (nonatomic,copy) UITextField *tfR;
@property (nonatomic,copy) UITextField *tfG;
@property (nonatomic,copy) UITextField *tfB;
@property (nonatomic,copy) UITextField *tfAlpha;
@property (nonatomic, nonnull,copy) UIButton *buttonBlurView;//调回参数页面
@property (nonatomic) float RGBWithR;
@property (nonatomic) float RGBWithG;
@property (nonatomic) float RGBWithB;
@property (nonatomic) float RGBWithAlpha;
@property (nonatomic,copy) UIView *backView;//该视图盛放参数视图和颜色视图
@property (nonatomic, nonnull,copy) YXSlider *sliderV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _isMaskImage = NO;
    _isExchange = NO;
    _tintColor = nil;
    [self.view addSubview:self.imageView];
    [self layoutView];
}

//布局
- (void)layoutView{
    [self.view addSubview:self.labelWelcome];
    [self.view addSubview:self.backView];
    self.exchangeColorView.hidden = YES;
}

//懒加载
- (UIImageView *)imageView{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds)-50)];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        
#pragma  mark- 创建缩放手势
        _imageView.userInteractionEnabled = YES;
        UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchPic:)];
        [_imageView addGestureRecognizer:pinch];
        pinch.delegate = self;
        
#pragma mark- 拖拽手势
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panPic:)];
        [_imageView addGestureRecognizer:pan];
        pan.delegate = self;
        
#pragma mark- 点击手势
        UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(updownBlurValue)];
        [_imageView addGestureRecognizer:tapG];
        tapG.delegate = self;
    }
    
    return _imageView;
}
- (UILabel *)labelWelcome{
    if (!_labelWelcome) {
        _labelWelcome = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 20)];
        _labelWelcome.center = self.view.center;
        _labelWelcome.text = @"欢迎使用模糊工具";
        _labelWelcome.font = [UIFont systemFontOfSize:20];
        _labelWelcome.textAlignment = NSTextAlignmentCenter;
        _labelWelcome.textColor = [UIColor orangeColor];
    }
    
    return _labelWelcome;
}
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.bounds)-250, CGRectGetWidth(self.view.bounds)*2, 250)];
        _backView.backgroundColor = [UIColor lightGrayColor];
        [_backView addSubview:self.ballView];
        [_backView addSubview:self.exchangeColorView];
        UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(touchBaliViewValue)];
        tapG.delegate = self;
        tapG.numberOfTapsRequired = 1;
        tapG.numberOfTouchesRequired = 1;
        [_backView addGestureRecognizer:tapG];

    }
    return _backView;
}
- (UIView *)ballView{
    if (!_ballView) {
        _ballView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 250)];
        _ballView.backgroundColor = [UIColor lightGrayColor];
        [_ballView addSubview:self.button];
        [_ballView addSubview:self.buttonMask];
        [_ballView addSubview:self.buttonCancelMask];
        [_ballView addSubview:self.sliderView];
        [_ballView addSubview:self.sliderViewRadius];
        [_ballView addSubview:self.sliderViewSaturationDeltaFactor];
        
        //添加显示框
        [_ballView addSubview:self.tfBlur];
        [_ballView addSubview:self.tfBlurRadius];
        [_ballView addSubview:self.tfSaturationDeltaFactor];
        [_ballView addSubview:self.tfR];
        [_ballView addSubview:self.tfG];
        [_ballView addSubview:self.tfB];
        [_ballView addSubview:self.tfAlpha];
        [_ballView addSubview:self.buttonChangeColor];
        UILabel *labeBlur = [[UILabel alloc]initWithFrame:
                             CGRectMake(20, 70, 150, 10)];
        labeBlur.text = @"模糊度";
        [_ballView addSubview:labeBlur];
        UILabel *labeSaturationDeltaFactor = [[UILabel alloc]initWithFrame:
                                              CGRectMake(20, 120, 150, 10)];
        labeSaturationDeltaFactor.text = @"半径";
        [_ballView addSubview:labeSaturationDeltaFactor];
        UILabel *labeBlurRadius = [[UILabel alloc]initWithFrame:
                                   CGRectMake(20, 170, 150, 10)];
        labeBlurRadius.text = @"饱和度";
        [_ballView addSubview:labeBlurRadius];
        
    }
    
    return _ballView;
}

- (UIButton *)button{
    if (!_button) {
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(20, 30, 100, 30);
        [_button addTarget:self action:@selector(addImageValue) forControlEvents:UIControlEventTouchDown];
        [_button setTitle:@"添加底图" forState:UIControlStateNormal];
        _button.contentMode = UIViewContentModeScaleToFill;
        _button.backgroundColor = [UIColor cyanColor];
        
    }
    
    return _button;
}

- (UIButton *)buttonMask{
    if (!_buttonMask) {
        _buttonMask = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonMask.frame = CGRectMake(CGRectGetWidth(self.view.bounds) - 230*YXRATIO, 30, 100, 30);
        [_buttonMask addTarget:self action:@selector(addImageValueMask) forControlEvents:UIControlEventTouchDown];
        [_buttonMask setTitle:@"添加遮罩" forState:UIControlStateNormal];
        _buttonMask.contentMode = UIViewContentModeScaleToFill;
        _buttonMask.backgroundColor=  [UIColor cyanColor];
        
    }
    
    return _buttonMask;
}

- (UIButton *)buttonCancelMask{
    if (!_buttonCancelMask) {
        _buttonCancelMask = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonCancelMask.frame = CGRectMake(CGRectGetWidth(self.view.bounds) - 100, 30, 80, 30);
        [_buttonCancelMask addTarget:self action:@selector(cancelImageValueMask) forControlEvents:UIControlEventTouchDown];
        [_buttonCancelMask setTitle:@"取消遮罩" forState:UIControlStateNormal];
        _buttonCancelMask.contentMode = UIViewContentModeScaleToFill;
        _buttonCancelMask.backgroundColor=  [UIColor cyanColor];
    }
    return _buttonCancelMask;
}

- (UIImagePickerController *)pickerController{
    if (!_pickerController) {
        _pickerController = [[UIImagePickerController alloc]init];
        _pickerController.delegate = self;
        _pickerController.allowsEditing = YES;
    }
    
    return _pickerController;
}

- (UISlider *)sliderView{
    if (!_sliderView) {
        _sliderView = [[UISlider alloc]initWithFrame:CGRectMake(20, 95, 300*YXRATIO, 10)];
        _sliderView.thumbTintColor = [UIColor cyanColor];
        _sliderView.minimumTrackTintColor = [UIColor greenColor];
        _sliderView.maximumTrackTintColor = [UIColor blueColor];
        _sliderView.minimumValue = 0;
        _sliderView.maximumValue = 1;
        _sliderView.continuous = NO;
        
        //加事件
        [_sliderView addTarget:self action:@selector(sliderMe:) forControlEvents:UIControlEventValueChanged];
    }
    
    return _sliderView;
}

- (UISlider *)sliderViewRadius{
    if (!_sliderViewRadius) {
        _sliderViewRadius = [[UISlider alloc]initWithFrame:CGRectMake(20, 145, 300*YXRATIO, 10)];
        _sliderViewRadius.thumbTintColor = [UIColor cyanColor];
        _sliderViewRadius.minimumTrackTintColor = [UIColor greenColor];
        _sliderViewRadius.maximumTrackTintColor = [UIColor blueColor];
        _sliderViewRadius.minimumValue = 0;
        _sliderViewRadius.maximumValue = 1;
        _sliderViewRadius.value = 0.4;
        
        //加事件
        [_sliderViewRadius addTarget:self action:@selector(sliderMeRadius:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderViewRadius;
}
- (UISlider *)sliderViewSaturationDeltaFactor{
    if (!_sliderViewSaturationDeltaFactor) {
        _sliderViewSaturationDeltaFactor = [[UISlider alloc]initWithFrame:CGRectMake(20, 190, 300*YXRATIO, 10)];
        _sliderViewSaturationDeltaFactor.thumbTintColor = [UIColor cyanColor];
        _sliderViewSaturationDeltaFactor.minimumTrackTintColor = [UIColor greenColor];
        _sliderViewSaturationDeltaFactor.maximumTrackTintColor = [UIColor blueColor];
        _sliderViewSaturationDeltaFactor.minimumValue = 0;
        _sliderViewSaturationDeltaFactor.maximumValue = 1;
        _sliderViewSaturationDeltaFactor.value = 0.1;
        
        //加事件
        [_sliderViewSaturationDeltaFactor addTarget:self action:@selector(sliderMesaturationDeltaFactor:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderViewSaturationDeltaFactor;
}

- (UITextField *)tfBlur{
    if (!_tfBlur) {
        _tfBlur = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 85, 40, 20)];
        _tfBlur.text = @"";
        _tfBlur.backgroundColor = [UIColor whiteColor];
        _tfBlur.textColor = [UIColor blackColor];
        _tfBlur.delegate = self;
        _tfBlur.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfBlur;
}
- (UITextField *)tfBlurRadius{
    if (!_tfBlurRadius) {
        _tfBlurRadius = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 140, 40, 20)];
        _tfBlurRadius.text = @"40";
        _tfBlurRadius.backgroundColor = [UIColor whiteColor];
        _tfBlurRadius.textColor = [UIColor blackColor];
        _tfBlurRadius.delegate = self;
        _tfBlurRadius.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfBlurRadius;
}
- (UITextField *)tfSaturationDeltaFactor{
    if (!_tfSaturationDeltaFactor) {
        _tfSaturationDeltaFactor = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 185, 40, 20)];
        _tfSaturationDeltaFactor.text = @"1";
        _tfSaturationDeltaFactor.backgroundColor = [UIColor whiteColor];
        _tfSaturationDeltaFactor.textColor = [UIColor blackColor];
        _tfSaturationDeltaFactor.delegate = self;
        _tfSaturationDeltaFactor.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfSaturationDeltaFactor;
}

- (UIButton *)buttonChangeColor{
    if (!_buttonChangeColor) {
        _buttonChangeColor = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonChangeColor.frame = CGRectMake(CGRectGetWidth(self.view.bounds)- 100, 210, 80, 20);
        [_buttonChangeColor setTitle:@"修改颜色" forState:UIControlStateNormal];
        _buttonChangeColor.backgroundColor = [UIColor cyanColor];
        [_buttonChangeColor addTarget:self action:@selector(changeColorValue) forControlEvents:UIControlEventTouchDown];
    }
    
    return _buttonChangeColor;
}

- (UIView *)exchangeColorView{
    if (!_exchangeColorView) {
        _exchangeColorView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 250)];
        _exchangeColorView.backgroundColor = [UIColor lightGrayColor];
        [_exchangeColorView addSubview:self.labelR];
        [_exchangeColorView addSubview:self.labelG];
        [_exchangeColorView addSubview:self.labelB];
        [_exchangeColorView addSubview:self.labelAlpha];
        [_exchangeColorView addSubview:self.sliderR];
        [_exchangeColorView addSubview:self.sliderG];
        [_exchangeColorView addSubview:self.sliderB];
        [_exchangeColorView addSubview:self.sliderAlpha];
        [_exchangeColorView addSubview:self.tfR];
        [_exchangeColorView addSubview:self.tfG];
        [_exchangeColorView addSubview:self.tfB];
        [_exchangeColorView addSubview:self.tfAlpha];
        [_exchangeColorView addSubview:self.buttonBlurView];
    }
    
    return _exchangeColorView;
}
- (UILabel *)labelR{
    if (!_labelR) {
        _labelR = [[UILabel alloc]initWithFrame:CGRectMake(20, 30, 100, 20)];
        _labelR.text = @"R";
        _labelR.textColor = [UIColor blackColor];
    }
    return _labelR;
}
- (UILabel *)labelG{
    if (!_labelG) {
        _labelG = [[UILabel alloc]initWithFrame:CGRectMake(20, 75, 100, 20)];
        _labelG.text = @"G";
        _labelG.textColor = [UIColor blackColor];
    }
    
    return _labelG;
}
- (UILabel *)labelB{
    if (!_labelB) {
        _labelB = [[UILabel alloc]initWithFrame:CGRectMake(20, 120, 100, 20)];
        _labelB.text = @"B";
        _labelB.textColor = [UIColor blackColor];
    }
    
    return _labelB;
}
- (UILabel *)labelAlpha{
    if (!_labelAlpha) {
        _labelAlpha = [[UILabel alloc]initWithFrame:CGRectMake(20, 165, 100, 20)];
        _labelAlpha.text = @"ALPHA";
        _labelAlpha.textColor = [UIColor blackColor];
    }
    
    return _labelAlpha;
}
- (UISlider *)sliderR{
    if (!_sliderR) {
        _sliderR = [[UISlider alloc]initWithFrame:CGRectMake(20, 55, 300*YXRATIO, 10)];
        _sliderR.thumbTintColor = [UIColor cyanColor];
        _sliderR.minimumTrackTintColor = [UIColor greenColor];
        _sliderR.maximumTrackTintColor = [UIColor blueColor];
        _sliderR.minimumValue = 0;
        _sliderR.maximumValue = 255;
        [_sliderR addTarget:self action:@selector(changeImageRGBWithR:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderR;
}
- (UISlider *)sliderG{
    if (!_sliderG) {
        _sliderG = [[UISlider alloc]initWithFrame:CGRectMake(20, 100, 300*YXRATIO, 10)];
        _sliderG.thumbTintColor = [UIColor cyanColor];
        _sliderG.minimumTrackTintColor = [UIColor greenColor];
        _sliderG.maximumTrackTintColor = [UIColor blueColor];
        _sliderG.minimumValue = 0;
        _sliderG.maximumValue = 255;
        [_sliderG addTarget:self action:@selector(changeImageRGBWithG:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderG;
}
- (UISlider *)sliderB{
    if (!_sliderB) {
        _sliderB = [[UISlider alloc]initWithFrame:CGRectMake(20, 145, 300*YXRATIO, 10)];
        _sliderB.thumbTintColor = [UIColor cyanColor];
        _sliderB.minimumTrackTintColor = [UIColor greenColor];
        _sliderB.maximumTrackTintColor = [UIColor blueColor];
        _sliderB.minimumValue = 0;
        _sliderB.maximumValue = 255;
        [_sliderB addTarget:self action:@selector(changeImageRGBWithB:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderB;
}
- (UISlider *)sliderAlpha{
    if (!_sliderAlpha) {
        _sliderAlpha = [[UISlider alloc]initWithFrame:CGRectMake(20, 190, 300*YXRATIO, 10)];
        _sliderAlpha.thumbTintColor = [UIColor cyanColor];
        _sliderAlpha.minimumTrackTintColor = [UIColor greenColor];
        _sliderAlpha.maximumTrackTintColor = [UIColor blueColor];
        _sliderAlpha.minimumValue = 0;
        _sliderAlpha.maximumValue = 1;
        [_sliderAlpha addTarget:self action:@selector(changeImageRGBWithAlpha:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _sliderAlpha;
}
- (UITextField *)tfR{
    if (!_tfR) {
        _tfR = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 40, 50, 20)];
        _tfR.backgroundColor = [UIColor whiteColor];
        _tfR.textColor = [UIColor blackColor];
        _tfR.delegate = self;
        _tfR.text = @"0";
        _tfR.font = [UIFont systemFontOfSize:12];
        _tfR.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfR;
}
- (UITextField *)tfG{
    if (!_tfG) {
        _tfG = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 85, 50, 20)];
        _tfG.backgroundColor = [UIColor whiteColor];
        _tfG.textColor = [UIColor blackColor];
        _tfG.delegate = self;
        _tfG.text = @"0";
        _tfG.font = [UIFont systemFontOfSize:12];
        _tfG.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfG;
}
- (UITextField *)tfB{
    if (!_tfB) {
        _tfB = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 140, 50, 20)];
        _tfB.backgroundColor = [UIColor whiteColor];
        _tfB.textColor = [UIColor blackColor];
        _tfB.delegate = self;
        _tfB.text = @"0";
        _tfB.font = [UIFont systemFontOfSize:12];
        _tfB.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfB;
}
- (UITextField *)tfAlpha{
    if (!_tfAlpha) {
        _tfAlpha = [[UITextField alloc]initWithFrame:CGRectMake(300*YXRATIO+25, 185, 50, 20)];
        _tfAlpha.backgroundColor = [UIColor whiteColor];
        _tfAlpha.textColor = [UIColor blackColor];
        _tfAlpha.delegate = self;
        _tfAlpha.text = @"0";
        _tfAlpha.font = [UIFont systemFontOfSize:12];
        _tfAlpha.keyboardType = UIKeyboardTypeDefault;
    }
    
    return _tfAlpha;
}
- (UIButton *)buttonBlurView{
    if (!_buttonBlurView) {
        _buttonBlurView = [UIButton buttonWithType:UIButtonTypeCustom];
        _buttonBlurView.frame = CGRectMake(CGRectGetWidth(self.view.bounds)- 100, 210, 80, 20);
        [_buttonBlurView setTitle:@"修改参数" forState:UIControlStateNormal];
        _buttonBlurView.backgroundColor = [UIColor cyanColor];
        [_buttonBlurView addTarget:self action:@selector(changeBlurValue) forControlEvents:UIControlEventTouchDown];
    }
    
    return _buttonBlurView;
}

//缩放
-(void)pinchPic:(UIPinchGestureRecognizer *)pinch{
    
    //获取要缩放的视图
    UIImageView *imageVI = (UIImageView *)pinch.view;
    imageVI.transform = CGAffineTransformScale(imageVI.transform, pinch.scale, pinch.scale);
    pinch.scale = 1;
}

//拖拽的方法
-(void)panPic:(UIPanGestureRecognizer *)pan{
    UIImageView *viewI = (UIImageView *)pan.view;
    CGPoint point =[pan translationInView:viewI];
    viewI.transform = CGAffineTransformTranslate(viewI.transform, point.x, point.y );
    
    //还原
    [pan setTranslation:CGPointZero inView:viewI];
}

//选图
- (void)addImageValue{
    self.labelWelcome.hidden = YES;
    _isMaskImage = NO;
    [self presentViewController:self.pickerController animated:YES completion:nil];
}
- (void)addImageValueMask{
    self.labelWelcome.hidden = YES;
    _isMaskImage = YES;
    [self presentViewController:self.pickerController animated:YES completion:nil];
}

- (void)cancelImageValueMask{
    self.maskImage = nil;
    self.imageView.image = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                      WithRadius:[self.tfBlurRadius.text floatValue]
                                                       tintColor:_tintColor
                                           saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                       maskImage:self.maskImage];
}
#pragma mark- uiimagePickerController 的代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    //根据是否点击的是遮罩按钮选择获得图片进行赋值
    if (_isMaskImage) {
        self.maskImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        
    } else {
        self.image = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    }
    
    [self dismissViewControllerAnimated:YES completion:^{}];
    [self showBlurView];
    
    
}


//显示模糊试图
- (void)showBlurView{
    self.imageView.image = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                      WithRadius:[self.tfBlurRadius.text floatValue]
                                                       tintColor:_tintColor
                                           saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                       maskImage:self.maskImage];
}

#pragma mark - 修改模糊度/半径/饱和度
//模糊度
- (void)sliderMe:(UISlider *)sliderView{
    NSLog(@"模糊度");
    self.tfBlur.text = [NSString stringWithFormat:@"%.2f",sliderView.value];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                WithRadius:[self.tfBlurRadius.text floatValue]
                                                 tintColor:_tintColor
                                     saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                 maskImage:self.maskImage];
       dispatch_async(dispatch_get_main_queue(), ^{
           self.imageView.image = imageTemp;
       });
    });

}

//模糊半径
- (void)sliderMeRadius:(UISlider *)sliderView{
    NSLog(@"模糊半径");
    self.tfBlurRadius.text = [NSString stringWithFormat:@"%ld",(NSInteger)(sliderView.value*100)];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                WithRadius:[self.tfBlurRadius.text floatValue]
                                                 tintColor:_tintColor
                                     saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                 maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });

}

//模糊饱和度
- (void)sliderMesaturationDeltaFactor:(UISlider *)sliderView{
    NSLog(@"饱和度");
    self.tfSaturationDeltaFactor.text = [NSString stringWithFormat:@"%.1f",(sliderView.value*10)];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                WithRadius:[self.tfBlurRadius.text floatValue]
                                                 tintColor:_tintColor
                                     saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                 maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
}

//下滑
- (void)updownBlurValue{
    [self.tfBlur resignFirstResponder];
    [self.tfBlurRadius resignFirstResponder];
    [self.tfSaturationDeltaFactor resignFirstResponder];
    [self.tfR resignFirstResponder];
    [self.tfG resignFirstResponder];
    [self.tfB resignFirstResponder];
    [self.tfAlpha resignFirstResponder];
    [UIView animateWithDuration:0.3f animations:^{
        _backView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 30, CGRectGetWidth(self.view.bounds)*2, 250);
    } completion:^(BOOL finished) {
        
    }];
}

//升起调试框
- (void)touchBaliViewValue{
    [UIView animateWithDuration:0.3f animations:^{
        _backView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 250, CGRectGetWidth(self.view.bounds)*2, 250);
    } completion:^(BOOL finished) {}];
}

#pragma mark - UITextFieldDelegate的方法
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    [UIView animateWithDuration:0.3f animations:^{
        _backView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 500, CGRectGetWidth(self.view.bounds)*2, 250);
    } completion:^(BOOL finished) {}];
    
    return YES;
}

//return的方法
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    [UIView animateWithDuration:0.4f animations:^{
        _backView.frame = CGRectMake(0, CGRectGetHeight(self.view.bounds) - 250, CGRectGetWidth(self.view.bounds)*2, 250);
    } completion:^(BOOL finished) {}];
    
    return YES;
}

//结束编辑
- (void)textFieldDidEndEditing:(UITextField *)textField{
    self.sliderView.value = [self.tfBlur.text floatValue];
    self.sliderViewRadius.value = [self.tfBlurRadius.text floatValue]/100;
    self.sliderViewSaturationDeltaFactor.value = [self.tfSaturationDeltaFactor.text floatValue]/10;
    _tintColor = [UIColor colorWithRed:[self.tfR.text floatValue]/255.0
                                 green:[self.tfG.text floatValue]/255.0
                                  blue:[self.tfB.text floatValue]/255.0
                                 alpha:[self.tfAlpha.text floatValue]];
    self.sliderR.value = [self.tfR.text floatValue];
    self.sliderG.value = [self.tfG.text floatValue];
    self.sliderB.value = [self.tfB.text floatValue];
    self.sliderAlpha.value = [self.tfAlpha.text floatValue];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
}

//点击
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.tfBlur resignFirstResponder];
    [self.tfBlurRadius resignFirstResponder];
    [self.tfSaturationDeltaFactor resignFirstResponder];
    [self.tfR resignFirstResponder];
    [self.tfG resignFirstResponder];
    [self.tfB resignFirstResponder];
    [self.tfAlpha resignFirstResponder];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
}

- (void)changeColorValue{
    self.ballView.hidden = YES;
    self.exchangeColorView.hidden = NO;
}

- (void)changeBlurValue{
    self.exchangeColorView.hidden = YES;
    self.ballView.hidden = NO;
}

#pragma mark- 修改RGB
//R
- (void)changeImageRGBWithR:(UISlider*) slider{
    self.tfR.text = [ NSString stringWithFormat:@"%.2f",slider.value];
    _tintColor = [UIColor colorWithRed:[self.tfR.text floatValue]/255.0
                                 green:[self.tfG.text floatValue]/255.0
                                  blue:[self.tfB.text floatValue]/255.0
                                 alpha:[self.tfAlpha.text floatValue]];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
}

//G
- (void)changeImageRGBWithG:(UISlider*) slider{
    self.tfG.text = [ NSString stringWithFormat:@"%.2f",slider.value];
    _tintColor = [UIColor colorWithRed:[self.tfR.text floatValue]/255.0
                                 green:[self.tfG.text floatValue]/255.0
                                  blue:[self.tfB.text floatValue]/255.0
                                 alpha:[self.tfAlpha.text floatValue]];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
}

//B
- (void)changeImageRGBWithB:(UISlider*) slider{
    self.tfB.text = [ NSString stringWithFormat:@"%.2f",slider.value];
    _tintColor = [UIColor colorWithRed:[self.tfR.text floatValue]/255.0
                                 green:[self.tfG.text floatValue]/255.0
                                  blue:[self.tfB.text floatValue]/255.0
                                 alpha:[self.tfAlpha.text floatValue]];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
    
}

//ALPHA
- (void)changeImageRGBWithAlpha:(UISlider*) slider{
    self.tfAlpha.text = [ NSString stringWithFormat:@"%.2f",slider.value];
    _tintColor = [UIColor colorWithRed:[self.tfR.text floatValue]/255.0
                                 green:[self.tfG.text floatValue]/255.0
                                  blue:[self.tfB.text floatValue]/255.0
                                 alpha:[self.tfAlpha.text floatValue]];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *imageTemp = [self.image imageBluredwithBlurNumber:[self.tfBlur.text floatValue]
                                                        WithRadius:[self.tfBlurRadius.text floatValue]
                                                         tintColor:_tintColor
                                             saturationDeltaFactor:[self.tfSaturationDeltaFactor.text floatValue]
                                                         maskImage:self.maskImage];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = imageTemp;
        });
    });
    
}

-(BOOL)gestureRecognizer:(UIGestureRecognizer*)gestureRecognizer shouldReceiveTouch:(UITouch*)touch {
    
    if([touch.view isKindOfClass:[UISlider class]])
        
        return NO;
    
    else
        
        return YES;
    
}

@end
